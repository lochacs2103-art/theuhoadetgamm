// Lấy các thẻ HTML ra để thao tác
const slider = document.getElementById('freqSlider');
const label = document.getElementById('freqLabel');
const toggleBtn = document.getElementById('toggleBtn');
const idiomList = document.getElementById('idiomList');
const adjList = document.getElementById('adjList');
const labels = ["Ít (Khắt khe)", "Vừa phải", "Nhiều (Thoải mái)"];

// Tab switching
const tabIdiom = document.getElementById('tabIdiom');
const tabAdj = document.getElementById('tabAdj');
const panelIdiom = document.getElementById('panelIdiom');
const panelAdj = document.getElementById('panelAdj');

tabIdiom.addEventListener('click', () => {
    tabIdiom.classList.add('active');
    tabAdj.classList.remove('active');
    panelIdiom.classList.remove('hidden');
    panelAdj.classList.add('hidden');
});

tabAdj.addEventListener('click', () => {
    tabAdj.classList.add('active');
    tabIdiom.classList.remove('active');
    panelAdj.classList.remove('hidden');
    panelIdiom.classList.add('hidden');
});

// 1. Khi mở popup lên, kiểm tra xem trước đó user đã lưu cài đặt gì chưa
chrome.storage.sync.get(['freqSetting', 'dgEnabled'], (result) => {
    // Xử lý thanh trượt
    const savedFreq = result.freqSetting || 2;
    slider.value = savedFreq;
    label.innerText = labels[savedFreq - 1];
    updateColor(savedFreq);

    // Xử lý nút bật tắt
    toggleBtn.checked = result.dgEnabled !== false;
});

// 2. Bắt sự kiện người dùng
slider.addEventListener('input', (e) => {
    const val = parseInt(e.target.value);
    
    label.innerText = labels[val - 1];
    updateColor(val);

    chrome.storage.sync.set({ freqSetting: val });
});

toggleBtn.addEventListener('change', (e) => {
    const isTurnedOn = e.target.checked;

    chrome.storage.sync.set({ dgEnabled: isTurnedOn });

    if (isTurnedOn) {
        console.log("⚡ Bấm ON! Đang đánh thức Server Render...");
        fetch("https://api-detgamtheuhoa.onrender.com/")
            .then(res => console.log("🌅 Server đã sẵn sàng quét!"))
            .catch(err => console.log("Lỗi gọi server:", err));
    }
});

// Hàm đổi màu chữ cho đẹp (Xanh lá -> Vàng -> Cam)
function updateColor(val) {
    if (val === 1) label.style.color = "#00b894";
    if (val === 2) label.style.color = "#fdcb6e";
    if (val === 3) label.style.color = "#e17055";
}

// 3. Lấy dữ liệu từ content.js của tab hiện tại
chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    if (tabs.length === 0) return;
    chrome.tabs.sendMessage(tabs[0].id, { action: "getFoundIdioms"}, function(response) {
        if (chrome.runtime.lastError || !response) return;

        // Hiển thị ca dao / tục ngữ
        if (response.idioms && response.idioms.length > 0) {
            idiomList.innerHTML = "";
            response.idioms.forEach(item => {
                let li = document.createElement("li");
                li.innerHTML = `<strong>${item.idiom}</strong><span style="color:#636e72;">"${item.phrase}"</span>`;
                idiomList.appendChild(li);
            });
        }

        // Hiển thị tính từ
        if (response.adjectives && response.adjectives.length > 0) {
            adjList.innerHTML = "";
            // Cập nhật badge số lượng trên tab
            tabAdj.textContent = `🌿 Tính từ (${response.adjectives.length})`;

            response.adjectives.forEach(adj => {
                let li = document.createElement("li");
                li.innerHTML = `
                    <strong class="adj-word">${adj.word}</strong>
                    <span class="adj-meaning">${adj.meaning}</span>
                    <span class="adj-english">🇬🇧 ${adj.english}</span>
                `;
                adjList.appendChild(li);
            });
        }
    });
});
