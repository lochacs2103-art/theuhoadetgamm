console.log("🚀 Dệt Gấm Thêu Hoa: Chế độ Nhuộm Đỏ");

// 1. Khởi tạo CSS & Tooltip
const style = document.createElement('style');
style.textContent = `
    .dg-red-hot {
        background-color: #d63031 !important;
        color: white !important;
        padding: 2px 4px !important;
        border-radius: 4px !important;
        cursor: help !important;
        font-weight: bold !important;
        display: inline !important;
        border-bottom: 2px solid #b2bec3 !important;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2) !important;
    }
    .dg-adj-highlight {
        background-color: #00b894 !important;
        color: white !important;
        padding: 2px 4px !important;
        border-radius: 4px !important;
        cursor: help !important;
        font-weight: bold !important;
        display: inline !important;
        border-bottom: 2px solid #55efc4 !important;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2) !important;
    }
    .dg-tooltip {
        display: none; position: fixed; z-index: 2147483647;
        background: #2d3436; color: white; padding: 12px;
        border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.4);
        max-width: 300px; pointer-events: none; font-size: 14px;
        border-left: 5px solid #ff7675; line-height: 1.5; font-family: sans-serif;
    }
    .dg-adj-tooltip {
        display: none; position: fixed; z-index: 2147483647;
        background: #2d3436; color: white; padding: 12px;
        border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.4);
        max-width: 300px; pointer-events: none; font-size: 14px;
        border-left: 5px solid #00b894; line-height: 1.5; font-family: sans-serif;
    }
`;
document.head.appendChild(style);

// Tooltip cho ca dao/tục ngữ (đỏ)
const tooltip = document.createElement("div");
tooltip.className = "dg-tooltip";
document.body.appendChild(tooltip);

// Tooltip cho tính từ (xanh lá)
const adjTooltip = document.createElement("div");
adjTooltip.className = "dg-adj-tooltip";
document.body.appendChild(adjTooltip);

// 2. Xử lý UI (Tooltip bám chuột)
document.addEventListener("mouseover", (e) => {
    // Tooltip ca dao/tục ngữ
    const redTarget = e.target.closest(".dg-red-hot");
    if (redTarget) {
        tooltip.innerHTML = `
            <div style="color: #ff7675; font-weight: bold; margin-bottom: 5px;">💡 ${redTarget.dataset.idiom}</div>
            <div style="opacity: 0.9;">${redTarget.dataset.meaning}</div>
        `;
        tooltip.style.display = "block";
        adjTooltip.style.display = "none";
    }

    // Tooltip tính từ
    const adjTarget = e.target.closest(".dg-adj-highlight");
    if (adjTarget) {
        adjTooltip.innerHTML = `
            <div style="color: #55efc4; font-weight: bold; margin-bottom: 5px;">🌿 Tính từ: ${adjTarget.dataset.word}</div>
            <div style="opacity: 0.9; margin-bottom: 4px;">📖 ${adjTarget.dataset.meaning}</div>
            <div style="color: #81ecec; font-style: italic;">🇬🇧 ${adjTarget.dataset.english}</div>
        `;
        adjTooltip.style.display = "block";
        tooltip.style.display = "none";
    }
});

document.addEventListener("mousemove", (e) => {
    if (tooltip.style.display === "block") {
        tooltip.style.left = (e.clientX + 15) + "px";
        tooltip.style.top = (e.clientY + 15) + "px";
    }
    if (adjTooltip.style.display === "block") {
        adjTooltip.style.left = (e.clientX + 15) + "px";
        adjTooltip.style.top = (e.clientY + 15) + "px";
    }
});

document.addEventListener("mouseout", (e) => {
    if (e.target.closest(".dg-red-hot")) tooltip.style.display = "none";
    if (e.target.closest(".dg-adj-highlight")) adjTooltip.style.display = "none";
});

// --- 2. QUẢN LÝ CÀI ĐẶT VÀ LƯU TRỮ ---
let appSettings = { isOn: true, freq: 2 };
let foundIdiomsLog = [];
let foundAdjectivesLog = [];

// Tải cài đặt lúc mới load web
chrome.storage.sync.get(['dgEnabled', 'freqSetting'], (res) => {
    if (res.dgEnabled !== undefined) appSettings.isOn = res.dgEnabled;
    if (res.freqSetting !== undefined) appSettings.freq = res.freqSetting;
});

// Lắng nghe khi người dùng bấm đổi trong Popup
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync') {
        if (changes.dgEnabled) appSettings.isOn = changes.dgEnabled.newValue;
        if (changes.freqSetting) appSettings.freq = changes.freqSetting.newValue;
    }
});

// Lắng nghe yêu cầu lấy danh sách từ Popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === "getFoundIdioms") {
        sendResponse({ idioms: foundIdiomsLog, adjectives: foundAdjectivesLog });
    }
});

// --- 3. QUẢN LÝ HÀNG ĐỢI ---
let requestQueue = [];
let isProcessing = false;

async function processQueue() {
    if (!appSettings.isOn) {
        requestQueue = [];
        isProcessing = false;
        return;
    }

    if (isProcessing || requestQueue.length === 0) return;
    isProcessing = true;

    while (requestQueue.length > 0) {
        if (!appSettings.isOn) break;

        const { el, text } = requestQueue.shift();
        
        // Gửi request cho Backend
        await new Promise(resolve => {
            chrome.runtime.sendMessage(
                { action: "scanText", text: text, frequency: appSettings.freq },
                (res) => {
                    if (res && res.matchFound) {
                        console.log(`🎯 AI duyệt khớp: ${res.idiom} - Bắn cụm: "${res.focusPhrase}"`);
                        foundIdiomsLog.push({ idiom: res.idiom, meaning: res.meaning, phrase: res.focusPhrase });
                        applyFocusRed(el, res.idiom, res.meaning, res.focusPhrase);
                    }

                    // Xử lý tính từ (luôn có nếu backend trả về)
                    if (res && res.adjectives && res.adjectives.length > 0) {
                        res.adjectives.forEach(adj => {
                            // Tránh thêm trùng lặp vào log
                            const alreadyLogged = foundAdjectivesLog.some(a => a.word === adj.word);
                            if (!alreadyLogged) {
                                foundAdjectivesLog.push(adj);
                            }
                            applyAdjectiveHighlight(el, adj);
                        });
                    }

                    resolve();
                }
            );
        });

        // Nghỉ 7 giây giữa mỗi lần gửi để Groq không bị quá tải
        await new Promise(r => setTimeout(r, 7000));
    }
    isProcessing = false;
}

// 4. LOGIC QUÉT VĂN BẢN
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const el = entry.target;
            if (el.innerText.trim().length > 50 && !el.dataset.scanned && appSettings.isOn) {
                el.dataset.scanned = 'true';
                requestQueue.push({ el, text: el.innerText.trim() });
                processQueue();
            }
        }
    });
}, { threshold: 0.1 });

setTimeout(() => {
    document.querySelectorAll('p, h2, h3').forEach(el => observer.observe(el));
}, 1500);

// 5. HÀM NHUỘM ĐỎ (ca dao/tục ngữ)
function applyFocusRed(element, idiom, meaning, focusPhrase) {
    const originalHTML = element.innerHTML;
    let targetText = "";

    if (focusPhrase && focusPhrase.length > 0 && originalHTML.includes(focusPhrase)) {
        targetText = focusPhrase;
    } else {
        const textOnWeb = element.innerText;
        const sentences = textOnWeb.split(/([.!?\n])/g).filter(s => s.trim().length > 10);
        targetText = sentences.length > 0 ? sentences[0].trim() : textOnWeb.substring(0, 30).trim();
    }

    if (targetText && originalHTML.includes(targetText)) {
        const redSpan = `<span class="dg-red-hot" 
            data-idiom="${idiom.replace(/"/g, '&quot;')}" 
            data-meaning="${meaning.replace(/"/g, '&quot;')}">${targetText}</span>`;
        element.innerHTML = originalHTML.replace(targetText, redSpan);
    } else {
        element.classList.add("dg-red-hot");
        element.dataset.idiom = idiom;
        element.dataset.meaning = meaning;
    }
}

// 6. HÀM TÔ XANH LÁ (tính từ)
function applyAdjectiveHighlight(element, adj) {
    const { word, meaning, english } = adj;
    const currentHTML = element.innerHTML;

    // Tìm từ trong HTML (tránh tô lại những từ đã được tô)
    if (!currentHTML.includes(word)) return;

    // Dùng regex để tìm từ đứng độc lập (không nằm trong thẻ HTML)
    // Thay thế lần xuất hiện đầu tiên chưa nằm trong thẻ span
    const escapedWord = word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(?<!<[^>]*)\\b(${escapedWord})\\b`, '');

    if (regex.test(currentHTML)) {
        const greenSpan = `<span class="dg-adj-highlight"
            data-word="${word.replace(/"/g, '&quot;')}"
            data-meaning="${meaning.replace(/"/g, '&quot;')}"
            data-english="${english.replace(/"/g, '&quot;')}">${word}</span>`;
        element.innerHTML = currentHTML.replace(regex, greenSpan);
    }
}
