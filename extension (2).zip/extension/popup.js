// Lấy các thẻ HTML ra để thao tác
const slider = document.getElementById('freqSlider');
const label = document.getElementById('freqLabel');
const toggleBtn = document.getElementById('toggleBtn');
const idiomList = document.getElementById('idiomList');
const labels = ["Ít (Khắt khe)", "Vừa phải", "Nhiều (Thoải mái)"];

// 1. Khi mở popup lên, kiểm tra xem trước đó user đã lưu cài đặt gì chưa
chrome.storage.sync.get(['freqSetting', 'dgEnabled'], (result) => {
    // Xử lý thanh trượt
    const savedFreq = result.freqSetting || 2;
    slider.value = savedFreq;
    label.innerText = labels[savedFreq - 1];
    updateColor(savedFreq);

    // Xử lý nút bật tắt
    toggleBtn.checked = result.dgEnabled !== false;
});

// 2. Bắt sự kiện người dùng
slider.addEventListener('input', (e) => {
    const val = parseInt(e.target.value);
    
    // Cập nhật chữ hiển thị
    label.innerText = labels[val - 1];
    updateColor(val);

    // Lưu ngay vào bộ nhớ trình duyệt (Chrome Storage)
    chrome.storage.sync.set({ freqSetting: val });
});

toggleBtn.addEventListener('change', (e) => {
    const isTurnedOn = e.target.checked;

    chrome.storage.sync.set({ dgEnabled: isTurnedOn });

    if (isTurnedOn) {
        console.log("⚡ Bấm ON! Đang đánh thức Server Render...");
        fetch("https://api-detgamtheuhoa.onrender.com/")
            .then(res => console.log("🌅 Server đã sẵn sàng quét!"))
            .catch(err => console.log("Lỗi gọi server:", err));
    }
    
});

// Hàm đổi màu chữ cho đẹp (Xanh lá -> Vàng -> Cam)
function updateColor(val) {
    if (val === 1) label.style.color = "#00b894"; // Xanh
    if (val === 2) label.style.color = "#fdcb6e"; // Vàng
    if (val === 3) label.style.color = "#e17055"; // Cam
}

chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    if (tabs.length === 0) return;
    chrome.tabs.sendMessage(tabs[0].id, { action: "getFoundIdioms"}, function(response) {
        if (chrome.runtime.lastError || !response || !response.idioms) {
            return;
        }

        if (response.idioms.length > 0) {
            idiomList.innerHTML = ""; // Xóa dòng "Đang quét..."
            response.idioms.forEach(item => {
                let li = document.createElement("li");
                li.innerHTML = `<strong>${item.idiom}</strong><span style="color:#636e72;">"${item.phrase}"</span>`;
                idiomList.appendChild(li);
            });
        }
    })
})